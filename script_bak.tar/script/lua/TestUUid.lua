local uuid = require('resty.jit-uuid')
-- uuid.seed()

ngx.log(ngx.DEBUG,'uuid1:' .. uuid())
ngx.log(ngx.DEBUG,'uuid2:' .. uuid())
ngx.log(ngx.DEBUG,'uuid3:' .. uuid())