local redisHelper = require('redisHelper')
local json = require('cjson')

-- 认证token
JwtUtil.auth(true)

redisHelper.Init()

local data = redisHelper.get('data')
local dataTable = json.decode(data)
local systemInfo = dataTable['system_info']

redisHelper.Close()

ngx.say(json.encode(systemInfo['data']))
