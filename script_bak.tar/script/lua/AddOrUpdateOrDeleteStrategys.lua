local systemInfo = require('UpdateSystem')
local json = require('cjson')
local mkill = require('KillMyself')

-- 认证token
JwtUtil.auth()

local reqData = systemInfo.getPostArgs()
local newdata = json.decode(reqData)
-- 判断是新增、编辑还是删除
local crud = newdata['crud']
if crud == 'addOrUpdate' then
    -- 策略数据
    local data = systemInfo.dealStrategy(newdata)
    Log('data:' .. TableUtil.TableToStr(data))
elseif crud == 'delete' then
    systemInfo.deleteStrategy(newdata)
end

-- 重启
mkill.reboot()