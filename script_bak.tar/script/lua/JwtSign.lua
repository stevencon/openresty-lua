local expire_time = JwtConfigTable['expire_time']

JwtUtil.sign(expire_time)