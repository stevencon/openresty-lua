local Json = require('cjson')
local strategyIp = ngx.ctx.strategyIp
local rewriteLogic = require('RewriteLogic')

ngx.log(ngx.DEBUG, '进行rewrite规则过滤')
-- ngx.log(ngx.DEBUG, 'server_port:' .. ngx.var.server_port)
-- ngx.log(ngx.DEBUG, 'reqIp:' .. reqIp)

-- 查看上下文是否有策略，然后执行相应的操作
ngx.log(ngx.DEBUG, 'strategyIsExist:' .. tostring(ngx.ctx.strategyIsExist))
if ngx.ctx.strategyIsExist then
    if strategyIp ~= nil then
        -- redisHelper.Init()
        -- local sValue = redisHelper.get(prefix .. strategyIp)
        -- redisHelper.Close()
        local sValue = rewriteLogic.getStrategy()
        if sValue ~= ngx.null then
            local strategy = Json.decode(sValue)
            if strategy ~= nil then
                -- 进行规则过滤
                local isMatch = rewriteLogic.MatchRules(strategy)
                if isMatch then
                    -- 符合规则，根据响应类型走不同的流程
                    Log('符合规则')
                    rewriteLogic.ExecuteActionByType(strategy)
                else
                    -- 不符合规则，直接跳转目标站点
                    Log('不符合规则')
                    rewriteLogic.NotMatchRule(strategy)
                end
            end
        end
    end
else
    rewriteLogic.SetRewrite()
end
