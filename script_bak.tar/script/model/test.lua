local _M = {}
function _M.test()
    return 1
end

function _M.Test1(param)
    return param
end

return _M
